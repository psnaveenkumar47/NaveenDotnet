﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCAssignment.ViewModel
{
    public class StudentViewmodel
    {
        public int StudentId { get; set; }
        public string StudentName { get; set; }
        public int age { get; set; }
        public string IdColor { get; set; }
    }
}