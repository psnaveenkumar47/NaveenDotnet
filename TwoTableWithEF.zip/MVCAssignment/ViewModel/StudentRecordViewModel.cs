﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCAssignment.ViewModel
{
    public class StudentRecordViewModel
    {
        public List<StudentViewmodel> MyStudent { get; set; }
    }
}