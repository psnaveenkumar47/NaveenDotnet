﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCAssignment.Models
{
    public class UserDetails
    {
        public string UserID { get; set; }
        public string Password { get; set; }
    }
}